import tkinter as tk
from PIL import Image, ImageTk
import random

# === Setup ===
root = tk.Tk()
root.title("Rock, Paper, Scissors")
root.geometry("850x700")
root.config(bg="#1e1e2f")

# === Load and resize images ===
def load_image(path, size, flip=False):
    img = Image.open(path).resize(size)
    if flip:
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
    return ImageTk.PhotoImage(img)

# Hand gestures
rock_img = load_image("rock.png", (150, 150))
paper_img = load_image("paper.png", (150, 150))
scissors_img = load_image("scisspr.png", (150, 150))

# Flipped for right-side player
rock_img_r = load_image("rock.png", (150, 150), flip=True)
paper_img_r = load_image("paper.png", (150, 150), flip=True)
scissors_img_r = load_image("scisspr.png", (150, 150), flip=True)

# Avatars
player1_avatar = load_image("player.png", (100, 100))
player2_avatar = load_image("player2.png", (100, 100))
computer_avatar = load_image("computer.png", (100, 100))

# Choices
choices = ["Rock", "Paper", "Scissors"]
img_dict = {"Rock": rock_img, "Paper": paper_img, "Scissors": scissors_img}
img_dict_r = {"Rock": rock_img_r, "Paper": paper_img_r, "Scissors": scissors_img_r}

# Scores and state
score1 = 0
score2 = 0
mode = "PvC"
turn = 1
player1_choice = ""

# UI Variables
score_var = tk.StringVar()
result_var = tk.StringVar()
winner_var = tk.StringVar()
log_var = tk.StringVar()
turn_var = tk.StringVar()

# === UI ===
tk.Label(root, text="Rock, Paper, Scissors", font=("Helvetica", 24, "bold"), bg="#1e1e2f", fg="#f4f4f4").pack(pady=10)

# Mode selector
def switch_mode(new_mode):
    global mode, score1, score2
    mode = new_mode
    reset_game()

mode_frame = tk.Frame(root, bg="#1e1e2f")
mode_frame.pack()
tk.Label(mode_frame, text="Mode:", font=("Helvetica", 12), bg="#1e1e2f", fg="white").grid(row=0, column=0)
tk.Button(mode_frame, text="👤 Vs 💻", command=lambda: switch_mode("PvC")).grid(row=0, column=1, padx=5)
tk.Button(mode_frame, text="👤 Vs 👤", command=lambda: switch_mode("PvP")).grid(row=0, column=2, padx=5)

# Score display
tk.Label(root, textvariable=score_var, font=("Helvetica", 16), bg="#1e1e2f", fg="#76ff03").pack()

# Game area
game_frame = tk.Frame(root, bg="#1e1e2f")
game_frame.pack(pady=20)

# Left Player
left_label = tk.Label(game_frame, text="Player 1", font=("Helvetica", 16), bg="#1e1e2f", fg="white")
left_label.grid(row=0, column=0)
tk.Label(game_frame, image=player1_avatar, bg="#1e1e2f").grid(row=1, column=0)
left_hand = tk.Label(game_frame, bg="#1e1e2f")
left_hand.grid(row=2, column=0)

# VS
tk.Label(game_frame, text="VS", font=("Helvetica", 20, "bold"), bg="#1e1e2f", fg="#ffffff").grid(row=2, column=1, padx=30)

# Right Player
right_label = tk.Label(game_frame, text="Computer", font=("Helvetica", 16), bg="#1e1e2f", fg="white")
right_label.grid(row=0, column=2)
avatar_right = tk.Label(game_frame, image=computer_avatar, bg="#1e1e2f")
avatar_right.grid(row=1, column=2)
right_hand = tk.Label(game_frame, bg="#1e1e2f")
right_hand.grid(row=2, column=2)

# Result
tk.Label(root, textvariable=result_var, font=("Helvetica", 18), bg="#1e1e2f", fg="#03a9f4").pack(pady=5)
tk.Label(root, textvariable=turn_var, font=("Helvetica", 14), bg="#1e1e2f", fg="orange").pack()
tk.Label(root, textvariable=winner_var, font=("Helvetica", 20, "bold"), fg="gold", bg="#1e1e2f").pack()
tk.Label(root, text="History", font=("Helvetica", 12), bg="#1e1e2f", fg="white").pack()
tk.Label(root, textvariable=log_var, font=("Courier", 12), bg="#1e1e2f", fg="#cccccc", justify="left").pack()

# === Gameplay ===
def update_score_display():
    score_var.set(f"Score — P1: {score1} | {'Computer' if mode == 'PvC' else 'P2'}: {score2}")

def play(choice):
    global score1, score2, turn, player1_choice

    if mode == "PvC":
        comp_choice = random.choice(choices)
        left_hand.config(image=img_dict[choice])
        right_hand.config(image=img_dict_r[comp_choice])
        if choice == comp_choice:
            result = "It's a Draw!"
        elif (choice == "Rock" and comp_choice == "Scissors") or \
             (choice == "Paper" and comp_choice == "Rock") or \
             (choice == "Scissors" and comp_choice == "Paper"):
            result = "You Win!"
            score1 += 1
        else:
            result = "You Lose!"
            score2 += 1

        result_var.set(result)
        log_var.set(f"You: {choice} | Computer: {comp_choice}\n" + log_var.get().split("\n", 4)[0])
        update_score_display()
        check_winner()

    elif mode == "PvP":
        if turn == 1:
            player1_choice = choice
            result_var.set("Player 2, your turn...")
            turn_var.set("Waiting for Player 2...")
            left_hand.config(image=img_dict[choice])
            right_hand.config(image="")
            turn = 2
        else:
            player2_choice = choice
            left_hand.config(image=img_dict[player1_choice])
            right_hand.config(image=img_dict_r[player2_choice])
            turn = 1
            turn_var.set("Player 1, your turn...")
            if player1_choice == player2_choice:
                result = "It's a Draw!"
            elif (player1_choice == "Rock" and player2_choice == "Scissors") or \
                 (player1_choice == "Paper" and player2_choice == "Rock") or \
                 (player1_choice == "Scissors" and player2_choice == "Paper"):
                result = "Player 1 Wins!"
                score1 += 1
            else:
                result = "Player 2 Wins!"
                score2 += 1

            result_var.set(result)
            log_var.set(f"P1: {player1_choice} | P2: {player2_choice}\n" + log_var.get().split("\n", 4)[0])
            update_score_display()
            check_winner()

def check_winner():
    if score1 == 5:
        winner_var.set("🏆 Player 1 Wins the Match!")
        disable_buttons()
    elif score2 == 5:
        winner_var.set(f"🏆 {'Computer' if mode == 'PvC' else 'Player 2'} Wins the Match!")
        disable_buttons()

def reset_game():
    global score1, score2, turn, player1_choice
    score1 = 0
    score2 = 0
    turn = 1
    player1_choice = ""
    result_var.set("")
    winner_var.set("")
    log_var.set("")
    turn_var.set("Player 1, your turn..." if mode == "PvP" else "")
    left_hand.config(image="")
    right_hand.config(image="")
    avatar_right.config(image=computer_avatar if mode == "PvC" else player2_avatar)
    right_label.config(text="Computer" if mode == "PvC" else "Player 2")
    update_score_display()
    enable_buttons()

def disable_buttons():
    for child in button_frame.winfo_children():
        child.config(state="disabled")

def enable_buttons():
    for child in button_frame.winfo_children():
        child.config(state="normal")

# === Buttons ===
button_frame = tk.Frame(root, bg="#1e1e2f")
button_frame.pack(pady=10)

tk.Button(button_frame, text="Rock ✊", width=12, bg="#3949ab", fg="white", command=lambda: play("Rock")).grid(row=0, column=0, padx=10)
tk.Button(button_frame, text="Paper ✋", width=12, bg="#00acc1", fg="white", command=lambda: play("Paper")).grid(row=0, column=1, padx=10)
tk.Button(button_frame, text="Scissors ✌️", width=12, bg="#ef5350", fg="white", command=lambda: play("Scissors")).grid(row=0, column=2, padx=10)

# === Reset/Quit ===
control_frame = tk.Frame(root, bg="#1e1e2f")
control_frame.pack(pady=15)

tk.Button(control_frame, text="🔄 Reset", command=reset_game, bg="#cfd8dc", fg="black").grid(row=0, column=0, padx=20)
tk.Button(control_frame, text="❌ Quit", command=root.destroy, bg="#f44336", fg="white").grid(row=0, column=1, padx=20)

reset_game()
root.mainloop()
